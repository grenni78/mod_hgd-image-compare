/******************************************************************************
 * filename mod_hgd-image-compare.js
 *
 * Javascript-Funktionalität für HGD Image Compare
 *
 * @author  Holger Genth -Dienstleistungen- (https://holger-genth.de)
 * @copyright Copyright (c) 2014 - 2017. All rights reserved.
 * @license GNU General Public License version 2 or later: http://www.gnu.org/copyleft/gpl.html
 */

 /*****************************************************************************
  * Drag plugin
  */
  (function($){
      $.fn.hgdSlider = function(options) {

          var settings = $.extend({
            // drag vertically
            vert: false,
            // drag horizontally
            horz: true,
            handler: '.handler',
            ondrag: $.noop,
            ondragstart: $.noop,
            ondragend: $.noop
          }, options );

          var touch = true;

          var element = this;
          var handler = $(settings.handler,this);

          var elPosition = element.position();
          var elOffset = element.offset();
          var parent = element.offsetParent();
          var parentBBox = parent.offset();
          parentBBox.right = parentBBox.left + parent.width();
          parentBBox.bottom = parentBBox.top + parent.height();
          var pos = {};


          var end = function(e) {
              e.preventDefault();
              var orig = e.originalEvent;

              settings.ondragend({
                  top: orig.changedTouches[0].pageY,
                  left: orig.changedTouches[0].pageX
              });
          };
          var up = function(e) {
              $(document).off("mouseup", up);
              handler.off("mousemove", mmove);
              settings.ondragend(pos);
          };
          var mmove = function(e) {
            if (e.pageX < parentBBox.left) e.pageX = parentBBox.left;
            if (e.pageX > parentBBox.right) e.pageX = parentBBox.right;
            if (e.pageY < parentBBox.top) e.pageY = parentBBox.top;
            if (e.pageY > parentBBox.bottom) e.pageY = parentBBox.bottom;

            pos = {
                left: e.pageX - elOffset.left + elPosition.left,
                top: e.pageY - elOffset.top + elPosition.top
            };

            if (settings.horz)
              element.css('left',pos.left);
            if (settings.vert)
              element.css('top',pos.top);

            settings.ondrag(pos)

            $(document).on("mouseup", up);
          }



          if (!("ontouchstart" in document.documentElement)) {
              touch = false;
          }

          if (touch) {
            handler.bind("touchstart", function(e) {
                var orig = e.originalEvent;
                pos = {
                    left: orig.changedTouches[0].pageX - elOffset.left,
                    top: orig.changedTouches[0].pageY - elOffset.top
                };
                settings.ondragstart(pos);
            });
            handler.bind("touchmove", function(e) {
                e.preventDefault();
                var orig = e.originalEvent;
                pos = {
                  left: orig.changedTouches[0].pageX,
                  top : orig.changedTouches[0].pageY
                };

                // do now allow two touch points to drag the same element
                if (orig.targetTouches.length > 1)
                    return;

                settings.ondrag(pos);
            });
            handler.on("touchend", end);
            handler.on("touchcancel", end);
          } else {
            $(document).on('selectstart',function(){return false;});
            handler.on('dragstart',function(){return false;});
            handler.on("mousedown", function(e) {
                element.trigger('dragstart');
                elPosition = element.position();
                elOffset = element.offset();

                pos = {
                    left: e.pageX - elOffset.left,
                    top: e.pageY - elOffset.top
                };
                handler.on("mousemove", mmove );
                settings.ondragstart(pos);

            });
          }

          return this;
      };

  })(jQuery);
/*****************************************************************************
 * Image compare Plugin
 */
(function($){

  $.fn.hgdImageCompare = function(options) {
    // window size
    var ww = 0;
    var wh = 0;
    // container size
    var cw = 0;
    var ch = 0;
    // image sizes
    var iw = 0;
    var ih = 0;
    // Breite des Maken-Element
    var mw = 0;
    // get elements
    var $container = this;
    var $separator = $container.find('.separator');
    var $img1 = $container.find('.image-1');
    var $img2 = $container.find('.image-2');

    var separator_offs = 0;
    /*-------------------------------------------------------------------------
     * calcAndSetSize
     *
     * berechnet und setzt die Größe aller Elemente
     *
     *------------------------------------------------------------------------*/
    function calcAndSetSize() {
      // Größe des größten Bildes herausfinden
      var width = (options.image1.width > options.image2.width) ? options.image1.width : options.image2.width;
      var height = (options.image1.height > options.image2.height) ? options.image1.height : options.image2.height;
      var sizeFactor = 1;

      // Größe des Browser-Fensters
      ww = $(window).innerWidth();
      wh = $(window).innerHeight();
      // Größe des Containers
      cw = $container.width();
      ch = $container.height();

      mw = $container.find('.mask').width();

      // die Container-Größe soll automatisch angepasst werden
      if (options.autoHeight) {
        // Seitenverhältnis des Bildes
        var aspect = width / height;
        // containerhöhe anpassen
        ch = cw / aspect;
        $container.css('height',ch);
      }
      // Faktor bestimmen, im die Bilder auf die Container-Größe anzupassen
      sizeFactor = cw / width;
      // Offset zum Verschieben des Trenners
      separator_offs = $separator.width() / 2;
      // Größe der Bilder setzen
      $container.find('.mask img').css({
        width: width * sizeFactor,
        height: height * sizeFactor
      });

    }
    // Resize-Ereignis abfangen
    $(window).resize(calcAndSetSize);

    calcAndSetSize();

    // den Separator initialisieren
    $separator.hgdSlider({
      horz: true,
      vert: false,
      handler: ".handler",
      ondrag: function(pos) {
        var left = pos.left + separator_offs;
        $img1.css('width',left);
        $img2.css('width', mw-left);
      }
    });

    return this;
  }

})(jQuery);
