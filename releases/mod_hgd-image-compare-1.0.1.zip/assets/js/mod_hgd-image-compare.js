/******************************************************************************
 * filename mod_hgd-image-compare.js
 *
 * Javascript-Funktionalität für HGD Image Compare
 *
 * @author  Holger Genth -Dienstleistungen- (https://holger-genth.de)
 * @copyright Copyright (c) 2014 - 2017. All rights reserved.
 * @license GNU General Public License version 2 or later: http://www.gnu.org/copyleft/gpl.html
 */
(function($){

  $.fn.hgdImageCompare = function(options) {
    // window size
    var ww = 0;
    var wh = 0;
    // container size
    var cw = 0;
    var ch = 0;
    // image sizes
    var iw = 0;
    var ih = 0;
    // Breite des Maken-Element
    var mw = 0;
    // get elements
    var $container = this;
    var $separator = $container.find('.separator');
    var $img1 = $container.find('.image-1');
    var $img2 = $container.find('.image-2');

    var separator_offs = 0;
    /*-------------------------------------------------------------------------
     * calcAndSetSize
     *
     * berechnet und setzt die Größe aller Elemente
     *
     *------------------------------------------------------------------------*/
    function calcAndSetSize() {
      // Größe des größten Bildes herausfinden
      var width = (options.image1.width > options.image2.width) ? options.image1.width : options.image2.width;
      var height = (options.image1.height > options.image2.height) ? options.image1.height : options.image2.height;
      var sizeFactor = 1;

      // Größe des Browser-Fensters
      ww = $(window).innerWidth();
      wh = $(window).innerHeight();
      // Größe des Containers
      cw = $container.width();
      ch = $container.height();

      mw = $container.find('.mask').width();

      // die Container-Größe soll automatisch angepasst werden
      if (options.autoHeight) {
        // Seitenverhältnis des Bildes
        var aspect = width / height;
        // containerhöhe anpassen
        ch = cw / aspect;
        $container.css('height',ch);
      }
      // Faktor bestimmen, im die Bilder auf die Container-Größe anzupassen
      sizeFactor = cw / width;
      // Offset zum Verschieben des Trenners
      separator_offs = $separator.width() / 2;
      // Größe der Bilder setzen
      $container.find('.mask img').css({
        width: width * sizeFactor,
        height: height * sizeFactor
      });

    }
    // Resize-Ereignis abfangen
    $(window).resize(calcAndSetSize);

    calcAndSetSize();

    // den Separator initialisieren
    $separator.draggable({
      axis: 'x',
      scroll: false,
      helper: 'clone',
      containment: $container,
      append: $container,
      handle: ".handler",
      refreshPositions: true,
      drag: function(ev, ui) {
        var pos = ui.position.left + separator_offs;
        $img1.css('width',pos);
        $img2.css('width', mw-pos);
        $separator.css('left',ui.position.left);
      }
    });

    return this;
  }

})(jQuery);